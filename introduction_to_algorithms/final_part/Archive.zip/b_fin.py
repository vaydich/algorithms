# 62653481
from typing import List, Tuple


def get_total_points(k, arr):
    total_points = 0
    for t in range(1, 10):
        n_count = get_n_count(t, arr)
        if n_count == 0:
            continue

        if n_count <= k * 2:
            total_points += 1

    return total_points


def get_n_count(n, arr) -> int:
    counter = 0
    for sub_arr in arr:
        for k in sub_arr:
            if k == '.':
                continue

            if k == n:
                counter += 1

    return counter


def read_input() -> Tuple[int, List[List[int]]]:
    k = int(input())
    matrix = []
    for i in range(4):
        matrix.append([x if x == '.' else int(x) for x in input().strip()])
    return k, matrix


def main():
    k, matrix = read_input()
    n_total_points = get_total_points(k, matrix)
    print(n_total_points)


if __name__ == '__main__':
    main()
